// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <string>

// Reads user input safely and reports whether it fits within the allowed length.
// Using std::string prevents writing beyond a fixed-size character buffer.
bool read_user_input(std::string& user_input, const std::size_t max_length)
{
    std::getline(std::cin, user_input);

    if (user_input.length() > max_length)
    {
        // Reject oversized input rather than copying/truncating it into a fixed buffer.
        return false;
    }

    return true;
}

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // The account number remains unchanged and directly before the input variable,
    // as required by the activity instructions.
    const std::string account_number = "CharlieBrown42";
    std::string user_input;

    // The original char[20] can safely hold at most 19 characters plus a null terminator.
    const std::size_t max_input_length = 19;

    std::cout << "Enter a value: ";

    const bool input_accepted = read_user_input(user_input, max_input_length);

    if (!input_accepted)
    {
        std::cout << "Buffer overflow attempt prevented: input exceeds "
                  << max_input_length << " characters." << std::endl;
        std::cout << "Account Number = " << account_number << std::endl;
        return 0;
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
