// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Lufranc Kousse Akodjo
// CS 405 Secure Coding
// Module Three Exceptions Activity

#include <exception>
#include <iostream>
#include <stdexcept>

// Custom exception derived from std::exception, as required by the activity.
class CustomApplicationException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application exception occurred.";
    }
};

void do_even_more_custom_application_logic()
{
    // Throw a standard C++ exception so the caller can handle it.
    throw std::runtime_error("Standard exception from even more custom application logic.");
}

void do_custom_application_logic()
{
    // Wrap code that can throw and catch a standard exception locally.
    try
    {
        std::cout << "Running Custom Application Logic." << std::endl;
        do_even_more_custom_application_logic();
    }
    catch (const std::exception& ex)
    {
        std::cout << "Caught standard exception in custom logic: "
                  << ex.what() << std::endl;
    }
}

void even_more_custom_application_logic()
{
    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;

    // Throw a custom exception derived from std::exception.
    throw CustomApplicationException();
}

float divide(float num, float den)
{
    // Floating-point division by zero normally does not throw in C++,
    // so explicitly reject a zero denominator with a standard exception.
    if (den == 0.0f)
    {
        throw std::domain_error("Division by zero is not allowed.");
    }

    return num / den;
}

void do_division() noexcept
{
    // Catch only the standard exception that divide() can throw.
    try
    {
        float numerator = 10.0f;
        float denominator = 0.0f;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator
                  << ") = " << result << std::endl;
    }
    catch (const std::domain_error& ex)
    {
        std::cout << "Caught division exception: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // The entire application is protected by ordered exception handlers:
    // custom exception first, standard exceptions second, catch-all last.
    try
    {
        do_division();
        do_custom_application_logic();
        even_more_custom_application_logic();
    }
    catch (const CustomApplicationException& ex)
    {
        std::cout << "Caught custom exception in main: "
                  << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        std::cout << "Caught standard exception in main: "
                  << ex.what() << std::endl;
    }
    catch (...)
    {
        // Final safety net for any otherwise unhandled exception.
        std::cout << "Caught an unknown unhandled exception." << std::endl;
    }

    std::cout << "Program completed safely." << std::endl;
    return 0;
}
