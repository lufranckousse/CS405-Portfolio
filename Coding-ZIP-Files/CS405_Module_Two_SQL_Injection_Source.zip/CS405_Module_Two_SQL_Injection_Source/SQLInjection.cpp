// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <locale>
#include <regex>
#include <string>
#include <tuple>
#include <vector>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
  if (possible_vector == NULL)
  { // no vector passed in, so just display the results
    for (int i = 0; i < argc; i++)
    {
      std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << std::endl;
  }
  else
  {
    std::vector< user_record >* rows =
      static_cast<std::vector< user_record > *>(possible_vector);

    rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
  }
  return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
  char* error_message = NULL;
  std::string sql = "CREATE TABLE USERS(" \
    "ID INT PRIMARY KEY     NOT NULL," \
    "NAME           TEXT    NOT NULL," \
    "PASSWORD       TEXT    NOT NULL);";

  int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }
  std::cout << "USERS table created." << std::endl;

  // insert some dummy data
  sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (1, 'Fred', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (2, 'Barney', 'Rubble');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (3, 'Wilma', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (4, 'Betty', 'Rubble');";

  result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// Remove the outer single quotes from a SQL string literal and convert doubled
// single quotes (SQL's way to represent an apostrophe) back to one quote.
std::string decode_sql_string_literal(const std::string& literal)
{
  std::string decoded;
  if (literal.size() < 2 || literal.front() != '\'' || literal.back() != '\'')
  {
    return literal;
  }

  for (std::size_t i = 1; i + 1 < literal.size(); ++i)
  {
    if (literal[i] == '\'' && i + 1 < literal.size() - 1 && literal[i + 1] == '\'')
    {
      decoded.push_back('\'');
      ++i;
    }
    else
    {
      decoded.push_back(literal[i]);
    }
  }
  return decoded;
}

// Return true when a numeric SQL literal can be parsed completely.
bool parse_numeric_literal(const std::string& literal, long double& value)
{
  char* end = nullptr;
  errno = 0;
  value = std::strtold(literal.c_str(), &end);
  return end != literal.c_str() && *end == '\0' && errno != ERANGE && std::isfinite(value);
}

// Detect the assignment's target attack: OR <literal> = <literal> where both
// literals have the same SQL value.  This is intentionally narrower than
// rejecting every OR clause so legitimate queries such as
// "... WHERE NAME='Fred' OR NAME='Barney'" continue to work.
bool contains_tautological_or(const std::string& sql)
{
  // A quoted string literal supports SQL's doubled-quote escape.  The numeric
  // form supports optional sign, decimal notation, and scientific notation.
  const std::string literal =
    R"((?:('(?:''|[^'])*')|([+-]?(?:(?:[0-9]+(?:\.[0-9]*)?)|(?:\.[0-9]+))(?:[eE][+-]?[0-9]+)?)))";

  const std::regex attack_pattern(
    std::string(R"(\bor\s+)") + literal + R"(\s*=\s*)" + literal,
    std::regex_constants::icase);

  for (std::sregex_iterator match(sql.begin(), sql.end(), attack_pattern), end; match != end; ++match)
  {
    // Groups 1/2 represent the left literal; groups 3/4 represent the right.
    const bool left_is_string = (*match)[1].matched;
    const bool right_is_string = (*match)[3].matched;

    if (left_is_string && right_is_string)
    {
      if (decode_sql_string_literal((*match)[1].str()) ==
          decode_sql_string_literal((*match)[3].str()))
      {
        return true;
      }
    }
    else if (!left_is_string && !right_is_string)
    {
      const std::string left_number = (*match)[2].str();
      const std::string right_number = (*match)[4].str();
      long double left_value = 0.0L;
      long double right_value = 0.0L;

      if (parse_numeric_literal(left_number, left_value) &&
          parse_numeric_literal(right_number, right_value) &&
          left_value == right_value)
      {
        return true;
      }
    }
  }

  return false;
}

bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  // Clear prior results first so a rejected query cannot leave stale data in
  // the calling function's result vector.
  records.clear();

  // Prevent the query from reaching SQLite when it contains a tautological
  // OR literal comparison such as OR 1=1 or OR 'hack'='hack'.
  if (contains_tautological_or(sql))
  {
    std::cout << "SQL injection attempt detected and prevented. Query was not executed." << std::endl;
    return false;
  }

  char* error_message = nullptr;
  if(sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK)
  {
    std::cout << "Data failed to be queried from USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  std::string injectedSQL(sql);
  std::string localCopy(sql);

  // we work on the local copy because of the const
  std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
  if(localCopy.find_last_of(str_where) >= 0)
  { // this sql has a where clause
    if(localCopy.back() == ';')
    { // smart SQL developer terminated with a semicolon - we can fix that!
      injectedSQL.pop_back();
    }

    switch (rand() % 4)
    {
    case 1:
      injectedSQL.append(" or 2=2;");
      break;
    case 2:
      injectedSQL.append(" or 'hi'='hi';");
      break;
    case 3:
      injectedSQL.append(" or 'hack'='hack';");
      break;
    case 0:
    default:
      injectedSQL.append(" or 1=1;");
      break;
    }
  }

  return run_query(db, injectedSQL, records);
}

// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
  std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

  for (auto record : records)
  {
    std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
  }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
  std::vector< user_record > records;

  // query all
  std::string sql = "SELECT * from USERS";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  query 1
  sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  run query 1 with injection 5 times
  for (auto i = 0; i < 5; ++i)
  {
    if (!run_query_injection(db, sql, records)) continue;
    dump_results(sql, records);
  }

}

// Additional verification added after the required test sequence.  These
// checks show that the defensive logic handles the broader value=value case
// while still allowing a legitimate WHERE clause that contains OR.
void run_security_verification(sqlite3* db)
{
  std::cout << std::endl << "*** Additional SQL Injection Verification ***" << std::endl;

  std::vector<user_record> records;
  const std::vector<std::string> malicious_queries = {
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR 2=2;",
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR 01=1;",
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR 1.0=1;",
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR 'hi'='hi';",
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR 'it''s'='it''s';"
  };

  for (const auto& query : malicious_queries)
  {
    const bool allowed = run_query(db, query, records);
    std::cout << "Expected BLOCKED -> " << (allowed ? "FAILED" : "PASSED") << std::endl;
  }

  const std::string legitimate_or =
    "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred' OR NAME='Barney';";
  const bool legitimate_allowed = run_query(db, legitimate_or, records);
  std::cout << "Expected ALLOWED -> " << (legitimate_allowed ? "PASSED" : "FAILED") << std::endl;
  if (legitimate_allowed)
  {
    dump_results(legitimate_or, records);
  }
}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
  // initialize random seed:
  srand(time(nullptr));

  int return_code = 0;
  std::cout << "SQL Injection Example" << std::endl;

  // the database handle
  sqlite3* db = NULL;

  // open the database connection
  int result = sqlite3_open(":memory:", &db);

  if(result != SQLITE_OK)
  {
    std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
    return -1;
  }

  std::cout << "Connected to the database." << std::endl;

  // initialize our database
  if(!initialize_database(db))
  {
    std::cout << "Database Initialization Failed. Terminating." << std::endl;
    return_code = -1;
  }
  else
  {
    run_queries(db);
  }

  // Added verification only; the original required call above remains unchanged.
  run_security_verification(db);

  // close the connection if opened
  if(db != NULL)
  {
    sqlite3_close(db);
  }

  return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
