// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

/// <summary>
/// Encrypt or decrypt a source string using the provided key.
/// XOR is reversible, so the same function is used for both operations.
/// </summary>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Repeat the key as needed by using modulo to stay within its length.
    for (size_t i = 0; i < source_length; ++i)
    {
        output[i] = source[i] ^ key[i % key_length];
    }

    assert(output.length() == source_length);
    return output;
}

std::string read_file(const std::string& filename)
{
    // Binary mode preserves every byte and newline exactly as stored.
    std::ifstream input_file(filename, std::ios::binary);
    if (!input_file)
    {
        std::cerr << "Error: Unable to open input file: " << filename << std::endl;
        return {};
    }

    std::ostringstream buffer;
    buffer << input_file.rdbuf();
    return buffer.str();
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    const size_t pos = string_data.find('\n');

    if (pos != std::string::npos)
    {
        student_name = string_data.substr(0, pos);
        // Remove a carriage return when reading a Windows-formatted text file.
        if (!student_name.empty() && student_name.back() == '\r')
        {
            student_name.pop_back();
        }
    }

    return student_name;
}

std::string current_date()
{
    const std::time_t now = std::time(nullptr);
    std::tm local_time{};

#ifdef _WIN32
    localtime_s(&local_time, &now);
#else
    localtime_r(&now, &local_time);
#endif

    std::ostringstream date_stream;
    date_stream << std::put_time(&local_time, "%Y-%m-%d");
    return date_stream.str();
}

void save_data_file(const std::string& filename, const std::string& student_name,
                    const std::string& key, const std::string& data)
{
    // Binary mode is important because encrypted XOR output may contain any byte value.
    std::ofstream output_file(filename, std::ios::binary | std::ios::trunc);
    if (!output_file)
    {
        std::cerr << "Error: Unable to create output file: " << filename << std::endl;
        return;
    }

    // Required file format:
    // Line 1: student name
    // Line 2: timestamp (yyyy-mm-dd)
    // Line 3: key used
    // Line 4+: data
    output_file << student_name << '\n'
                << current_date() << '\n'
                << key << '\n';
    output_file.write(data.data(), static_cast<std::streamsize>(data.size()));
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    // Preserve the filename defined by the supplied starter code.
    const std::string decrypted_file_name = "decrytpteddatafile.txt";
    const std::string key = "password";

    const std::string source_string = read_file(file_name);
    if (source_string.empty())
    {
        std::cerr << "No input data was loaded. Program stopped." << std::endl;
        return 1;
    }

    const std::string student_name = get_student_name(source_string);
    if (student_name.empty())
    {
        std::cerr << "Unable to read the student name from the first line." << std::endl;
        return 1;
    }

    const std::string encrypted_string = encrypt_decrypt(source_string, key);
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Verify the XOR round trip before reporting success.
    if (decrypted_string != source_string)
    {
        std::cerr << "Error: Decrypted data does not match the original input." << std::endl;
        return 1;
    }

    std::cout << "Read File: " << file_name
              << " - Encrypted To: " << encrypted_file_name
              << " - Decrypted To: " << decrypted_file_name << std::endl;
    std::cout << "Verification: decrypted data matches the original input." << std::endl;

    return 0;
}
