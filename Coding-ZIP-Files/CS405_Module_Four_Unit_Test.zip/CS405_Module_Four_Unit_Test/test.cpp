// test.cpp
// CS 405 Module Four - Unit Testing
// Completed Google Test fixture for std::vector<int>.

#include <gtest/gtest.h>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <vector>

// Global test environment setup and tear down.
class Environment : public ::testing::Environment
{
public:
    ~Environment() override = default;

    void SetUp() override
    {
        // Initialize random seed used by add_entries().
        std::srand(static_cast<unsigned int>(std::time(nullptr)));
    }

    void TearDown() override
    {
    }
};

// Test fixture that provides a fresh vector for every test.
class CollectionTest : public ::testing::Test
{
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    {
        collection->clear();
        collection.reset(nullptr);
    }

    // Adds count random values from 0 through 99 to the collection.
    void add_entries(int count)
    {
        ASSERT_GE(count, 0);
        for (int i = 0; i < count; ++i)
        {
            collection->push_back(std::rand() % 100);
        }
    }
};

// Verifies that the smart pointer is created and owns a vector.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Positive test: a newly created vector must be empty and have size zero.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);
}

// Verifies adding one value to an empty collection.
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    ASSERT_TRUE(collection->empty());

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1U);
}

// Verifies adding five values to the collection.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    ASSERT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5U);
}

// Verifies max_size can accommodate the requested collection sizes.
TEST_F(CollectionTest, MaxSizeIsAtLeastCollectionSize)
{
    const std::vector<int> counts{0, 1, 5, 10};

    for (int count : counts)
    {
        collection->clear();
        add_entries(count);

        EXPECT_GE(collection->max_size(), collection->size());
    }
}

// Verifies capacity is never smaller than the number of stored elements.
TEST_F(CollectionTest, CapacityIsAtLeastCollectionSize)
{
    const std::vector<int> counts{0, 1, 5, 10};

    for (int count : counts)
    {
        collection->clear();
        add_entries(count);

        EXPECT_GE(collection->capacity(), collection->size());
    }
}

// Verifies resize can increase the logical size of the vector.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    collection->resize(10);

    EXPECT_EQ(collection->size(), 10U);
}

// Verifies resize can decrease the logical size of the vector.
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10U);

    collection->resize(5);

    EXPECT_EQ(collection->size(), 5U);
}

// Verifies resizing to zero makes the vector empty.
TEST_F(CollectionTest, ResizeToZeroEmptiesCollection)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verifies clear removes every element.
TEST_F(CollectionTest, ClearRemovesAllElements)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verifies erase(begin, end) removes the complete range.
TEST_F(CollectionTest, EraseFullRangeRemovesAllElements)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Verifies reserve changes capacity without changing logical size.
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    add_entries(5);
    const std::size_t original_size = collection->size();

    collection->reserve(20);

    EXPECT_GE(collection->capacity(), 20U);
    EXPECT_EQ(collection->size(), original_size);
}

// Negative test: at() must throw std::out_of_range for an invalid index.
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
    add_entries(3);

    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Custom positive test: push_back stores a known value at the end.
TEST_F(CollectionTest, PushBackStoresExpectedValue)
{
    collection->push_back(42);

    ASSERT_EQ(collection->size(), 1U);
    EXPECT_EQ(collection->back(), 42);
}

// Custom negative test: at() on an empty vector must throw std::out_of_range.
TEST_F(CollectionTest, AtOnEmptyVectorThrowsOutOfRange)
{
    ASSERT_TRUE(collection->empty());

    EXPECT_THROW(collection->at(0), std::out_of_range);
}

int main(int argc, char** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    ::testing::AddGlobalTestEnvironment(new Environment);
    return RUN_ALL_TESTS();
}
